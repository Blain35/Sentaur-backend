
const functions = require("firebase-functions");
const express = require("express");
const cors = require("cors");
const { Configuration, OpenAIApi } = require("openai");

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());

const openai = new OpenAIApi(new Configuration({
  apiKey: functions.config().openai.key,
}));

app.post("/ask", async (req, res) => {
  const prompt = req.body.prompt;
  try {
    const response = await openai.createChatCompletion({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
    });
    res.send({ reply: response.data.choices[0].message.content });
  } catch (err) {
    res.status(500).send({ error: err.message });
  }
});

exports.api = functions.https.onRequest(app);
